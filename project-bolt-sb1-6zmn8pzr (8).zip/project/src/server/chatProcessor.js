function parseWhatsAppChat(fileContent) {
  // 1. Preprocessing
  let cleanedContent = fileContent.replace(/<Media omitted>/g, '');
  cleanedContent = cleanedContent.replace(/\r\n/g, '\n');

  // 2. Parsing
  const messages = [];
  const lines = cleanedContent.split('\n');
  const messageRegex = /\[(.*?)\] (.*?): (.*)/;

  lines.forEach(line => {
    const match = line.match(messageRegex);
    if (match) {
      messages.push({
        date: match[1],
        sender: match[2],
        message: match[3].trim()
      });
    }
  });

  return messages;
}

module.exports = {
  parseWhatsAppChat
};