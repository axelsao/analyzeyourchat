const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const { parseWhatsAppChat } = require('./chatProcessor');

const app = express();
const port = 3001;

app.use(cors());
app.use(bodyParser.json({ limit: '50mb' }));

app.post('/analyze', async (req, res) => {
  try {
    const { fileContent } = req.body;
    
    if (!fileContent) {
      return res.status(400).json({ error: 'No file content provided' });
    }

    const messages = parseWhatsAppChat(fileContent);
    
    const analysis = {
      totalMessages: messages.length,
      participants: [...new Set(messages.map(m => m.sender))],
      messages: messages.slice(0, 100) // Send first 100 messages for preview
    };

    res.json(analysis);
  } catch (error) {
    console.error('Error processing chat:', error);
    res.status(500).json({ error: 'Failed to process chat file' });
  }
});