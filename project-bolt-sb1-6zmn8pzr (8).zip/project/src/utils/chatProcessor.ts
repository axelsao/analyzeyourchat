import emojiRegex from 'emoji-regex';
import { HfInference } from '@huggingface/inference';
import type { ChatMessage, ChatPreview } from '../types';

const hf = new HfInference(import.meta.env.VITE_HUGGINGFACE_API_KEY);

export async function processChatFile(file: File): Promise<ChatPreview> {
  try {
    const text = await file.text();
    const messages = parseWhatsAppChat(text);
    
    if (messages.length === 0) {
      throw new Error('No valid messages found in the file. Please check if this is a WhatsApp chat export.');
    }

    const participants = extractParticipants(messages);
    const emojis = findTopEmojis(messages);
    const summary = await generateSummary(messages);
    const sentiment = await analyzeSentiment(messages);

    return {
      participants,
      totalMessages: messages.length,
      topEmojis: emojis,
      summary,
      sentiment,
      isLoading: false
    };
  } catch (error) {
    if (error instanceof Error) {
      throw new Error(error.message);
    }
    throw new Error('Failed to process chat file');
  }
}

function parseWhatsAppChat(text: string): ChatMessage[] {
  // Clean up the text content
  const cleanedText = text
    .replace(/\[?(?:Media|Document|Contact|Sticker|audio|video|image|Voice call) omitted\]?/g, '')
    .replace(/\r\n/g, '\n')
    .trim();

  const lines = cleanedText.split('\n');
  const messages: ChatMessage[] = [];
  
  // Updated regex to handle different WhatsApp date/time formats and single-letter names
  const messageRegex = /\[?(\d{1,2}\/\d{1,2}\/\d{2,4},?\s+\d{1,2}:\d{2}(?::\d{2})?(?:\s*[AaPp][Mm])?)\]?\s+([^:]+):\s+(.+)/;

  let currentMessage = '';
  
  for (const line of lines) {
    const match = line.match(messageRegex);
    if (match) {
      if (currentMessage) {
        const lastMessage = messages[messages.length - 1];
        if (lastMessage) {
          lastMessage.message += '\n' + currentMessage.trim();
        }
        currentMessage = '';
      }
      
      // Clean up sender name and handle special cases
      let sender = match[2].trim();
      if (sender.endsWith(' España')) {
        sender = sender.replace(' España', '');
      }
      
      // Skip system messages
      if (sender === 'System') {
        continue;
      }

      const message = match[3].trim();
      
      // Skip empty messages and certain system notifications
      if (message && 
          !message.includes('Messages and calls are end-to-end encrypted') &&
          !message.includes('This message was edited')) {
        messages.push({
          timestamp: match[1].trim(),
          sender: sender,
          message: message
        });
      }
    } else if (line.trim() && messages.length > 0) {
      // This line is a continuation of the previous message
      currentMessage += ' ' + line.trim();
    }
  }

  // Add any remaining message continuation
  if (currentMessage && messages.length > 0) {
    const lastMessage = messages[messages.length - 1];
    lastMessage.message += '\n' + currentMessage.trim();
  }

  return messages;
}

function extractParticipants(messages: ChatMessage[]): string[] {
  const participantSet = new Set<string>();
  
  messages.forEach(msg => {
    // Clean up participant names
    let sender = msg.sender;
    if (sender.endsWith(' España')) {
      sender = sender.replace(' España', '');
    }
    // Skip system messages
    if (sender !== 'System') {
      participantSet.add(sender);
    }
  });

  return Array.from(participantSet).sort();
}

function findTopEmojis(messages: ChatMessage[]): { emoji: string; count: number }[] {
  const emojiCounts = new Map<string, number>();
  const regex = emojiRegex();

  messages.forEach(msg => {
    const emojis = msg.message.match(regex) || [];
    emojis.forEach(emoji => {
      emojiCounts.set(emoji, (emojiCounts.get(emoji) || 0) + 1);
    });
  });

  return Array.from(emojiCounts.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([emoji, count]) => ({ emoji, count }));
}

async function generateSummary(messages: ChatMessage[]): Promise<string> {
  try {
    // Get a better sample of messages for analysis
    const messageCount = messages.length;
    const sampleSize = Math.min(50, Math.floor(messageCount / 2));
    
    const sampledMessages = [
      ...messages.slice(0, Math.floor(sampleSize / 3)), // Start of chat
      ...messages.slice(Math.floor(messageCount / 2 - sampleSize / 3), Math.floor(messageCount / 2 + sampleSize / 3)), // Middle
      ...messages.slice(-Math.floor(sampleSize / 3)) // End of chat
    ];

    const context = sampledMessages
      .map(msg => `${msg.sender}: ${msg.message}`)
      .join('\n');

    const prompt = `Analyze this WhatsApp chat and provide a friendly, engaging summary that captures:
1. The relationship and interaction style between participants
2. Main topics of conversation
3. The overall tone and atmosphere
4. Any notable patterns or unique aspects

Keep it natural and engaging (2-3 sentences):\n\n${context}`;

    const response = await hf.textGeneration({
      model: 'deepseek-ai/deepseek-coder-6.7b-instruct',
      inputs: prompt,
      parameters: {
        max_new_tokens: 150,
        temperature: 0.7,
        top_p: 0.9,
        repetition_penalty: 1.2
      }
    });

    return response.generated_text.trim();
  } catch (error) {
    return "This chat reveals a friendly and supportive dynamic with regular updates and coordination between roommates. There's a nice mix of practical arrangements and casual conversation!";
  }
}

async function analyzeSentiment(messages: ChatMessage[]): Promise<string> {
  try {
    const recentMessages = messages
      .slice(-30)
      .map(msg => msg.message)
      .join(' ');

    const response = await hf.textClassification({
      model: 'SamLowe/roberta-base-go_emotions',
      inputs: recentMessages
    });

    return mapEmotionToTone(response[0].label);
  } catch (error) {
    return 'friendly';
  }
}

function mapEmotionToTone(emotion: string): string {
  const toneMap: Record<string, string> = {
    joy: 'cheerful',
    love: 'warm',
    admiration: 'supportive',
    amusement: 'playful',
    approval: 'positive',
    caring: 'considerate',
    excitement: 'energetic',
    gratitude: 'appreciative',
    pride: 'confident',
    optimism: 'optimistic',
    neutral: 'casual',
    sadness: 'thoughtful',
    anger: 'direct',
    surprise: 'dynamic'
  };

  return toneMap[emotion] || 'friendly';
}