import React from 'react';
import { MessageSquare, Sparkles } from 'lucide-react';

interface Props {
  progress: number;
}

export function LoadingOverlay({ progress }: Props) {
  return (
    <div className="fixed inset-0 bg-black z-50 flex items-center justify-center">
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(139,92,246,0.15),transparent_50%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(236,72,153,0.1),transparent_50%)]" />
      </div>
      
      <div className="relative max-w-md w-full px-8">
        <div className="flex flex-col items-center text-center">
          {/* Animated Logo */}
          <div className="relative w-24 h-24 mb-8">
            <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-primary-500 to-secondary-500 animate-pulse-slow" />
            <div className="absolute inset-0 flex items-center justify-center">
              <MessageSquare className="w-12 h-12 text-white animate-float" />
            </div>
          </div>

          {/* Loading Text */}
          <h3 className="text-2xl font-bold text-white mb-2">
            Creating Your Story
          </h3>
          <p className="text-white/60 mb-8">
            Hold tight while we analyze your messages and craft something special...
          </p>

          {/* Progress Bar */}
          <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden mb-6">
            <div 
              className="h-full bg-gradient-to-r from-primary-500 to-secondary-500 rounded-full transition-all duration-500 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>

          {/* Progress Steps */}
          <div className="w-full grid grid-cols-3 gap-4 text-sm">
            {[
              { label: 'Reading Messages', icon: MessageSquare, done: progress >= 33 },
              { label: 'Finding Patterns', icon: Sparkles, done: progress >= 66 },
              { label: 'Creating Magic', icon: Sparkles, done: progress >= 100 }
            ].map((step, index) => (
              <div 
                key={index}
                className={`text-center transition-colors duration-300 ${
                  step.done ? 'text-primary-400' : 'text-white/40'
                }`}
              >
                <step.icon className="w-5 h-5 mx-auto mb-2" />
                <div className="font-medium">{step.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}