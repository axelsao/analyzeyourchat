import React from 'react';
import { Users, MessageCircle, Smile, Sparkles, Lock, Lightbulb, Calendar, Clock, BarChart2, PieChart, Heart } from 'lucide-react';
import type { ChatPreview as ChatPreviewType } from '../types';

interface Props {
  preview: ChatPreviewType;
}

export function ChatPreview({ preview }: Props) {
  const { participants, totalMessages, topEmojis, summary, sentiment } = preview;

  return (
    <div className="relative">
      {/* Hero Section */}
      <div className="relative h-96 bg-gradient-to-br from-primary-600 via-primary-500 to-secondary-700 rounded-t-xl overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1516542076529-1ea3854896f2')] bg-cover bg-center opacity-10" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
        <div className="relative h-full flex flex-col justify-end p-8 text-white">
          <div className="flex items-center space-x-3 mb-4">
            <div className="p-3 bg-white/10 backdrop-blur-lg rounded-xl">
              <Lightbulb className="w-8 h-8" />
            </div>
            <div>
              <h4 className="text-sm font-medium opacity-90">Your Chat Story</h4>
              <h2 className="text-3xl font-bold">{participants.join(' & ')}</h2>
            </div>
          </div>
          <p className="text-xl leading-relaxed max-w-3xl opacity-90">
            {summary}
          </p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-8 bg-gradient-to-b from-black to-black/95">
        <StatsCard
          icon={<Users className="w-6 h-6" />}
          color="blue"
          label="Participants"
          value={participants.length.toString()}
          subtext={`${participants.length} amazing ${participants.length === 1 ? 'person' : 'people'}`}
        />
        <StatsCard
          icon={<MessageCircle className="w-6 h-6" />}
          color="purple"
          label="Messages"
          value={totalMessages.toLocaleString()}
          subtext="conversations shared"
        />
        <StatsCard
          icon={<Smile className="w-6 h-6" />}
          color="yellow"
          label="Top Emojis"
          value={topEmojis.slice(0, 3).map(e => e.emoji).join(' ')}
          subtext="express yourself"
        />
        <StatsCard
          icon={<Heart className="w-6 h-6" />}
          color="red"
          label="Chat Vibe"
          value={sentiment}
          subtext="your unique style"
        />
      </div>

      {/* Activity Visualization */}
      <div className="p-8 space-y-8 bg-black/95">
        <section>
          <h3 className="text-xl font-bold mb-4 flex items-center text-white">
            <BarChart2 className="w-5 h-5 mr-2 text-primary-400" />
            Message Activity
          </h3>
          <div className="bg-white/5 backdrop-blur-sm p-6 rounded-xl">
            <div className="h-48 flex items-end space-x-1">
              {Array.from({ length: 24 }).map((_, i) => (
                <div
                  key={i}
                  className="flex-1 bg-gradient-to-t from-primary-500 to-secondary-500 rounded-t-sm"
                  style={{
                    height: `${20 + Math.random() * 80}%`,
                    opacity: 0.1 + Math.random() * 0.9
                  }}
                />
              ))}
            </div>
            <div className="mt-4 flex justify-between text-sm text-white/40">
              <span>00:00</span>
              <span>12:00</span>
              <span>23:59</span>
            </div>
          </div>
        </section>

        {/* Premium Features */}
        <section className="relative">
          <div className="absolute inset-0 bg-black/90 backdrop-blur-sm flex items-center justify-center rounded-xl z-10">
            <div className="text-center p-8">
              <div className="bg-gradient-to-br from-primary-500 to-secondary-500 p-4 rounded-full inline-block mb-4 shadow-lg">
                <Lock className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold mb-2 text-white">
                Unlock Your Complete Story
              </h3>
              <p className="text-white/60 mb-6 max-w-sm">
                Get detailed insights, interactive visualizations, and AI-powered analysis of your entire chat history
              </p>
              <button className="bg-gradient-to-r from-primary-500 to-secondary-500 text-white px-8 py-4 rounded-full font-medium hover:from-primary-600 hover:to-secondary-600 transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-0.5">
                Get Premium Report €10
              </button>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-6">
            <PreviewCard
              icon={<Calendar />}
              title="Timeline Analysis"
              description="See how your chat evolved"
            />
            <PreviewCard
              icon={<Clock />}
              title="Activity Patterns"
              description="Discover your peak chat times"
            />
          </div>
        </section>
      </div>
    </div>
  );
}

function StatsCard({ icon, color, label, value, subtext }: {
  icon: React.ReactNode;
  color: string;
  label: string;
  value: string;
  subtext: string;
}) {
  const colors = {
    blue: 'from-blue-500 to-blue-600',
    purple: 'from-purple-500 to-purple-600',
    yellow: 'from-yellow-500 to-yellow-600',
    red: 'from-red-500 to-red-600'
  };

  return (
    <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 hover:bg-white/10 transition-all group">
      <div className="inline-flex p-3 rounded-xl mb-4">
        <div className={`bg-gradient-to-br ${colors[color]} p-2 rounded-lg text-white transform group-hover:scale-110 transition-transform`}>
          {icon}
        </div>
      </div>
      <h3 className="text-sm font-medium text-white/60 mb-1">{label}</h3>
      <p className="text-2xl font-bold text-white mb-2">{value}</p>
      <p className="text-sm text-white/40">{subtext}</p>
    </div>
  );
}

function PreviewCard({ icon, title, description }: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6">
      <div className="flex items-center space-x-3 mb-4">
        <div className="text-white/40">
          {icon}
        </div>
        <div>
          <h3 className="font-medium text-white/40">{title}</h3>
          <p className="text-sm text-white/40">{description}</p>
        </div>
      </div>
      <div className="h-48 bg-white/5 rounded-lg animate-pulse" />
    </div>
  );
}