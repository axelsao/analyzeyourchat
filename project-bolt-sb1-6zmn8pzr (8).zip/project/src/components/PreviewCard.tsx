import React from 'react';
import type { PreviewCardProps } from '../types';

export function PreviewCard({ title, value, icon, className = '' }: PreviewCardProps) {
  return (
    <div className={`bg-white p-6 rounded-xl shadow-lg ${className}`}>
      <div className="flex items-center space-x-3 mb-3">
        <div className="p-2 bg-rose-100 rounded-lg text-rose-600">
          {icon}
        </div>
        <h3 className="font-medium text-gray-600">{title}</h3>
      </div>
      <p className="text-2xl font-semibold text-gray-800">{value}</p>
    </div>
  );
}