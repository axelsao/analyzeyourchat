export interface ChatMessage {
  timestamp: string;
  sender: string;
  message: string;
}

export interface TimeStats {
  firstMessage: string;
  lastMessage: string;
  durationDays: number;
}

export interface ChatAnalysis {
  participants: string[];
  totalMessages: number;
  messagesByParticipant: Record<string, number>;
  topEmojis: { emoji: string; count: number }[];
  timeStats: TimeStats;
  summary: string;
  sentiment: string;
  topics: { word: string; count: number }[];
  success: boolean;
}

export interface ChatPreview {
  participants: string[];
  totalMessages: number;
  topEmojis: { emoji: string; count: number }[];
  summary: string;
  sentiment: string;
  isLoading: boolean;
  error?: string;
}

export interface PreviewCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  className?: string;
}