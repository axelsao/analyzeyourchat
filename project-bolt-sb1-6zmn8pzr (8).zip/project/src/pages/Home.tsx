import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Upload, Lock, MessageSquare, Sparkles, Smartphone, FileText, ArrowRight, Shield } from 'lucide-react';
import { LoadingOverlay } from '../components/LoadingOverlay';
import { processChatFile } from '../utils/chatProcessor';

export function Home() {
  const [isDragging, setIsDragging] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const uploadRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const droppedFile = e.dataTransfer.files[0];
    await handleFile(droppedFile);
  };

  const handleFile = async (file: File) => {
    if (!file) return;
    
    if (file.type !== 'text/plain') {
      setError('Please upload a valid WhatsApp chat export (.txt file)');
      return;
    }

    setFile(file);
    setError(null);
    setIsLoading(true);
    
    try {
      // Slower progress simulation
      let progress = 0;
      const progressInterval = setInterval(() => {
        progress += 0.5; // Slower increment
        if (progress > 95) {
          clearInterval(progressInterval);
        }
        setProgress(progress);
      }, 100); // Longer interval

      const chatPreview = await processChatFile(file);
      
      // Add artificial delay before completion
      await new Promise(resolve => setTimeout(resolve, 1000));
      clearInterval(progressInterval);
      setProgress(100);
      
      // Add delay before navigation
      await new Promise(resolve => setTimeout(resolve, 500));
      
      sessionStorage.setItem('chatPreview', JSON.stringify(chatPreview));
      navigate('/report');
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to process chat file. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleUploadClick = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.txt';
    input.click();
    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        await handleFile(file);
      }
    };
  };

  if (isLoading) {
    return <LoadingOverlay progress={progress} />;
  }

  return (
    <div className="min-h-screen bg-black text-white">
      <div className="relative min-h-screen flex flex-col">
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(139,92,246,0.15),transparent_50%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(236,72,153,0.1),transparent_50%)]" />
        </div>
        
        <header className="relative px-4 py-6">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-xl bg-white/10 backdrop-blur-sm">
              <MessageSquare className="w-6 h-6 text-primary-400" />
            </div>
            <span className="text-xl font-bold gradient-text">ChatStory</span>
          </div>
        </header>

        <main className="flex-1 flex flex-col items-center justify-center px-4 py-12">
          <div className="relative text-center max-w-4xl mx-auto w-full">
            <div className="mb-6 inline-flex items-center px-4 py-2 rounded-full bg-white/5 backdrop-blur-sm border border-white/10">
              <Sparkles className="w-4 h-4 text-secondary-400 mr-2" />
              <span className="text-sm">Your WhatsApp Story Awaits</span>
            </div>
            
            <h1 className="text-4xl sm:text-5xl md:text-7xl font-bold mb-8 leading-tight">
              <span className="block gradient-text">Discover the Magic</span>
              <span className="block text-white/90">in Your Chats</span>
            </h1>
            
            <p className="text-lg sm:text-xl text-white/60 mb-12 max-w-2xl mx-auto">
              Upload your WhatsApp chat and watch as AI transforms it into a beautiful, 
              interactive story filled with insights and memories.
            </p>

            <div
              ref={uploadRef}
              onClick={handleUploadClick}
              className={`max-w-2xl mx-auto rounded-2xl p-6 sm:p-12 text-center transition-all glass-card border-2 ${
                isDragging 
                  ? 'border-primary-400 bg-primary-500/10' 
                  : 'border-white/10 hover:border-white/20'
              } cursor-pointer mb-16`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              <div className="mb-6">
                <div className="w-16 sm:w-20 h-16 sm:h-20 mx-auto rounded-2xl bg-gradient-to-br from-primary-500 to-secondary-500 p-4 sm:p-5 transform hover:scale-110 transition-transform">
                  <Upload className="w-full h-full text-white" />
                </div>
              </div>
              
              <h3 className="text-lg sm:text-xl font-semibold mb-2">
                {file ? file.name : "Drop Your WhatsApp Chat Here"}
              </h3>
              <p className="text-white/60 mb-4">or click to choose file</p>
              
              {error && (
                <p className="text-red-400 text-sm mb-4">{error}</p>
              )}
              
              <div className="inline-flex items-center px-4 py-2 rounded-full bg-white/5">
                <Lock className="w-4 h-4 mr-2 text-primary-400" />
                <span className="text-sm text-white/60">Your privacy is our priority</span>
              </div>
            </div>

            {/* How to Upload Instructions */}
            <div className="max-w-2xl mx-auto mb-8">
              <h2 className="text-2xl font-bold mb-8 text-white/90">How to Export Your Chat</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 text-left">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary-500 to-secondary-500 p-3 mb-4">
                    <Smartphone className="w-full h-full text-white" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2 text-white/90">1. Open WhatsApp</h3>
                  <p className="text-white/60 text-sm">
                    Open the chat you want to analyze in WhatsApp on your phone
                  </p>
                </div>

                <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 text-left">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary-500 to-secondary-500 p-3 mb-4">
                    <ArrowRight className="w-full h-full text-white" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2 text-white/90">2. Export Chat</h3>
                  <p className="text-white/60 text-sm">
                    Tap the three dots menu → More → Export chat → Without media
                  </p>
                </div>

                <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 text-left">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary-500 to-secondary-500 p-3 mb-4">
                    <FileText className="w-full h-full text-white" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2 text-white/90">3. Upload File</h3>
                  <p className="text-white/60 text-sm">
                    Save the .txt file and upload it here to see your chat story
                  </p>
                </div>
              </div>

              {/* Privacy Notice */}
              <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 text-center mb-24">
                <div className="inline-flex items-center justify-center space-x-2 mb-3">
                  <Shield className="w-5 h-5 text-primary-400" />
                  <span className="text-lg font-semibold text-white/90">100% Private & Secure</span>
                </div>
                <p className="text-white/60 text-sm">
                  Your chats are processed locally and never stored on our servers. We respect your privacy.
                </p>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}