import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Download, Share2 } from 'lucide-react';
import type { ChatPreview as ChatPreviewType } from '../types';
import { ChatPreview } from '../components/ChatPreview';

export function Report() {
  const [preview, setPreview] = useState<ChatPreviewType | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const storedPreview = sessionStorage.getItem('chatPreview');
    if (!storedPreview) {
      navigate('/');
      return;
    }
    setPreview(JSON.parse(storedPreview));
  }, [navigate]);

  if (!preview) {
    return null;
  }

  return (
    <div className="min-h-screen bg-black">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-black/50 backdrop-blur-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <button
                onClick={() => navigate('/')}
                className="text-white/80 hover:text-white flex items-center transition-colors"
              >
                <ArrowLeft className="w-5 h-5 mr-2" />
                Back to Home
              </button>
            </div>
            <div className="flex items-center space-x-4">
              <button className="inline-flex items-center px-4 py-2 text-sm font-medium rounded-full text-white/80 hover:text-white border border-white/20 hover:border-white/40 transition-colors">
                <Share2 className="w-4 h-4 mr-2" />
                Share Story
              </button>
              <button className="inline-flex items-center px-4 py-2 text-sm font-medium rounded-full text-black bg-white hover:bg-gray-100 transition-colors">
                <Download className="w-4 h-4 mr-2" />
                Download Report
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="pt-16">
        <div className="max-w-7xl mx-auto">
          <ChatPreview preview={preview} />
        </div>
      </main>
    </div>
  );
}