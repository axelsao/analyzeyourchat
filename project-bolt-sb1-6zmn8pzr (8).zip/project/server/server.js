import express from 'express';
import cors from 'cors';
import { HfInference } from '@huggingface/inference';
import { parseWhatsAppChat, extractTopics, calculateStatistics } from './chatProcessor.js';

const app = express();
const port = 3001;

const hf = new HfInference(process.env.HUGGINGFACE_API_KEY);

app.use(cors());
app.use(express.json({ limit: '50mb' }));

app.post('/analyze', async (req, res) => {
  try {
    const { fileContent } = req.body;
    
    if (!fileContent) {
      return res.status(400).json({ error: 'No file content provided' });
    }

    // Parse messages
    const messages = parseWhatsAppChat(fileContent);
    
    if (messages.length === 0) {
      return res.status(400).json({ error: 'No valid messages found in the file' });
    }

    // Calculate basic statistics
    const statistics = calculateStatistics(messages);

    // Extract topics (using last 50 messages for context)
    const context = messages
      .slice(-50)
      .map(msg => `${msg.sender}: ${msg.message}`)
      .join('\n');

    // Generate summary using Hugging Face
    const summaryResponse = await hf.textGeneration({
      model: 'deepseek-ai/deepseek-coder-6.7b-instruct',
      inputs: `Analyze this WhatsApp chat and provide a brief, friendly summary of the conversation dynamics and main topics discussed. Keep it concise and engaging:\n\n${context}`,
      parameters: {
        max_new_tokens: 150,
        temperature: 0.7,
        top_p: 0.9,
        repetition_penalty: 1.2
      }
    });

    // Analyze sentiment
    const sentimentContext = messages
      .slice(-20)
      .map(msg => msg.message)
      .join(' ');

    const sentimentResponse = await hf.textClassification({
      model: 'SamLowe/roberta-base-go_emotions',
      inputs: sentimentContext
    });

    // Extract topics
    const topics = await extractTopics(messages);

    // Combine all analysis results
    const analysis = {
      ...statistics,
      summary: summaryResponse.generated_text.trim(),
      sentiment: sentimentResponse[0].label,
      topics,
      success: true
    };

    res.json(analysis);
  } catch (error) {
    console.error('Error processing chat:', error);
    res.status(500).json({ 
      error: 'Failed to process chat file',
      details: error.message
    });
  }
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});