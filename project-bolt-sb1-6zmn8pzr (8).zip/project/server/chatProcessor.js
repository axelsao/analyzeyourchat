import emojiRegex from 'emoji-regex';

export function parseWhatsAppChat(text) {
  // Clean up the text content
  const cleanedText = text
    .replace(/<Media omitted>/g, '')
    .replace(/\r\n/g, '\n')
    .trim();

  const lines = cleanedText.split('\n');
  const messages = [];
  
  // This regex matches both 12h and 24h time formats
  const messageRegex = /\[?(\d{1,2}\/\d{1,2}\/\d{2,4},?\s+\d{1,2}:\d{2}(?::\d{2})?(?:\s*[AaPp][Mm])?)\]?\s+([-\w\s]+?):\s+(.+)/;

  for (const line of lines) {
    const match = line.match(messageRegex);
    if (match) {
      messages.push({
        timestamp: match[1].trim(),
        sender: match[2].trim(),
        message: match[3].trim()
      });
    }
  }

  return messages;
}

export function calculateStatistics(messages) {
  // Extract participants
  const participants = Array.from(new Set(messages.map(msg => msg.sender))).sort();

  // Count messages per participant
  const messagesByParticipant = {};
  participants.forEach(participant => {
    messagesByParticipant[participant] = messages.filter(msg => msg.sender === participant).length;
  });

  // Find top emojis
  const emojiCounts = new Map();
  const regex = emojiRegex();

  messages.forEach(msg => {
    const emojis = msg.message.match(regex) || [];
    emojis.forEach(emoji => {
      emojiCounts.set(emoji, (emojiCounts.get(emoji) || 0) + 1);
    });
  });

  const topEmojis = Array.from(emojiCounts.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([emoji, count]) => ({ emoji, count }));

  // Calculate time-based statistics
  const timestamps = messages.map(msg => new Date(msg.timestamp));
  const firstMessage = new Date(Math.min(...timestamps));
  const lastMessage = new Date(Math.max(...timestamps));
  const durationDays = Math.ceil((lastMessage - firstMessage) / (1000 * 60 * 60 * 24));

  return {
    participants,
    totalMessages: messages.length,
    messagesByParticipant,
    topEmojis,
    timeStats: {
      firstMessage: firstMessage.toISOString(),
      lastMessage: lastMessage.toISOString(),
      durationDays
    }
  };
}

export async function extractTopics(messages) {
  // Simple keyword extraction based on word frequency
  const words = messages
    .map(msg => msg.message.toLowerCase())
    .join(' ')
    .split(/\s+/)
    .filter(word => word.length > 3) // Filter out short words
    .filter(word => !['https', 'http', 'www'].includes(word)); // Filter out common URLs

  const wordFreq = {};
  words.forEach(word => {
    wordFreq[word] = (wordFreq[word] || 0) + 1;
  });

  return Object.entries(wordFreq)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([word, count]) => ({ word, count }));
}